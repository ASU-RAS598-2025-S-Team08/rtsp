from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='ros2_streamer',
            executable='image_to_rtsp',
            name='image_to_rtsp_node',
            output='screen'
        )
    ])
