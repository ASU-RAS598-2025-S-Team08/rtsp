import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

class ImageToRTSP(Node):
    def __init__(self):
        super().__init__('image_to_rtsp_node')
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.listener_callback,
            10)
        self.bridge = CvBridge()
        self.out = cv2.VideoWriter(
            'appsrc ! videoconvert ! x264enc tune=zerolatency bitrate=512 speed-preset=superfast ! rtspclientsink location=rtsp://127.0.0.1:8554/stream',
            cv2.CAP_GSTREAMER, 0, 20.0, (640, 480), True)

    def listener_callback(self, msg):
        cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        self.out.write(cv_image)

def main(args=None):
    rclpy.init(args=args)
    node = ImageToRTSP()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
