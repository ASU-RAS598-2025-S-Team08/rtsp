# TurtleBot4 RTSP + Navigation Dashboard Backend

This project provides a complete backend for:
- RTSP camera streaming from TurtleBot4 or webcam
- MJPEG HTTP relay for browser compatibility
- Navigation goal control via ROS2
- Pose and battery status monitoring
- Web-based GUI dashboard

## 🚀 Running Locally

### 1. Prerequisites
- ROS2 Humble
- Flask + ffmpeg + OpenCV
- Webcam or simulation camera topic

### 2. Start Backend
```bash
python3 launch_backend.py
```

### 3. Open Dashboard
Navigate to: [http://localhost:5000](http://localhost:5000)

---

## 🐳 Docker Usage

### Build
```bash
docker build -t turtlebot4-dashboard .
```

### Run
```bash
docker run -it --net=host turtlebot4-dashboard
```

> Use `--net=host` so ROS2 and Flask ports are accessible from the host system.
