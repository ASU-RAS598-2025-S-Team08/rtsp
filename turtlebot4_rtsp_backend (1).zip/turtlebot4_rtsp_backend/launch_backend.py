import subprocess
import time
import threading

def run_flask():
    subprocess.run(["python3", "app.py"])

def run_stream():
    subprocess.run(["python3", "relay/run_flask_mjpeg_proxy.py"])

if __name__ == "__main__":
    threading.Thread(target=run_stream, daemon=True).start()
    time.sleep(2)  # Wait for stream to initialize
    run_flask()
