import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from sensor_msgs.msg import BatteryState
from tf_transformations import euler_from_quaternion

status = {"pose": {"x": 0.0, "y": 0.0, "yaw": 0.0}, "battery": 0.0}

class StatusBridge(Node):
    def __init__(self):
        super().__init__('status_bridge')
        self.create_subscription(Odometry, '/odom', self.odom_cb, 10)
        self.create_subscription(BatteryState, '/battery_status', self.battery_cb, 10)

    def odom_cb(self, msg):
        pos = msg.pose.pose.position
        ori = msg.pose.pose.orientation
        _, _, yaw = euler_from_quaternion([ori.x, ori.y, ori.z, ori.w])
        status["pose"] = {"x": pos.x, "y": pos.y, "yaw": yaw}

    def battery_cb(self, msg):
        if msg.percentage:
            status["battery"] = msg.percentage * 100

def start_status_node():
    rclpy.init()
    node = StatusBridge()
    rclpy.spin(node)
