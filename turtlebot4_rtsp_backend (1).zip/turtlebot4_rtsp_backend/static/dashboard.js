function startStream() {
  fetch('/start_stream', { method: 'POST' })
    .then(res => res.json()).then(data => alert(data.status));
}

function stopStream() {
  fetch('/stop_stream', { method: 'POST' })
    .then(res => res.json()).then(data => alert(data.status));
}

function sendNavGoal(x, y, yaw = 0.0) {
  fetch('/navigate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ x, y, yaw })
  }).then(res => res.json()).then(data => alert(data.status));
}

function updateOverlay() {
  fetch('/robot_status')
    .then(res => res.json())
    .then(data => {
      document.getElementById('pose').innerText =
        `x: ${data.pose.x.toFixed(2)}, y: ${data.pose.y.toFixed(2)}, yaw: ${data.pose.yaw.toFixed(2)}`;
      document.getElementById('battery').innerText = `${data.battery.toFixed(1)}%`;
    })
    .catch(() => {
      document.getElementById('pose').innerText = "(unavailable)";
      document.getElementById('battery').innerText = "(unavailable)";
    });
}

setInterval(updateOverlay, 1000);
